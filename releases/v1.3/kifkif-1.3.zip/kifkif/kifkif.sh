java -Xmx512M -jar Kifkif.jar 
